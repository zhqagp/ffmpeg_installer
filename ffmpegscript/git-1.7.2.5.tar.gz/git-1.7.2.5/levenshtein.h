#ifndef LEVENSHTEIN_H
#define LEVENSHTEIN_H

int levenshtein(const char *string1, const char *string2,
	int swap_penalty, int substitution_penalty,
	int insertion_penalty, int deletion_penalty);

#endif
