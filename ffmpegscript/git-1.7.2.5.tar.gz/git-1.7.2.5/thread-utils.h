#ifndef THREAD_COMPAT_H
#define THREAD_COMPAT_H

extern int online_cpus(void);
extern int init_recursive_mutex(pthread_mutex_t*);

#endif /* THREAD_COMPAT_H */
