#! /bin/sh
autoreconf -i
